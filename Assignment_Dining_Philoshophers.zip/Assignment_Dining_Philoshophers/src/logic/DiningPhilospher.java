package logic;

import java.util.Scanner;

public class DiningPhilospher {
	public static void main(String[] args) throws Exception {
		//taking input from console for Philosopher
		System.out.println("Enter Number of Philosopher");
		Scanner in = new Scanner(System.in); 
		int n = in.nextInt();
        Philosopher[] philosophers = new Philosopher[n];
        
        Object[] forks = new Object[philosophers.length];
        //create forks 
        for (int i = 0; i < forks.length; i++) {
            forks[i] = new Object();
        }
 
        for (int i = 0; i < philosophers.length; i++) {
            Object leftFork = forks[i];
            Object rightFork = forks[(i + 1) % forks.length];
 
            if (i == philosophers.length - 1) {
                 
                // To prevent from the Deadlock the last philosopher picks up the right fork first
                philosophers[i] = new Philosopher(rightFork, leftFork); 
            } else {
                philosophers[i] = new Philosopher(leftFork, rightFork);
            }
             
            Thread t  = new Thread(philosophers[i], "Philosopher " + (i + 1));
            t.start();
        }
    }
}
