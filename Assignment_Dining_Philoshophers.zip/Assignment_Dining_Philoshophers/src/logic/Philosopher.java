package logic;

public class Philosopher implements Runnable  {

	 	private Object leftFork;//left fork
	    private Object rightFork;//right fork
	 
	    public Philosopher(Object leftFork, Object rightFork) {
	        this.leftFork = leftFork;
	        this.rightFork = rightFork;
	    }
	 
	    private void doAction(String action) throws InterruptedException {
	        System.out.println(
	          Thread.currentThread().getName() + " " + action);
	        Thread.sleep(((int) (Math.random() * 100)));
	    } 

	    @Override
	    public void run() {
	    	try {
	            while (true) { 
	                // thinking
	                doAction(":\tThinking");
	                synchronized (leftFork) {
	                    doAction( ": Picked up left fork");
	                    synchronized (rightFork) {
	                        // eating
	                        doAction(": Picked up right fork - \t Start Eating"); 
	                         
	                        doAction(": Put down right fork");
	                    }
	                    // Back to thinking
	                    doAction(": Put down left fork. \tBack to thinking");
	                }
	            }
	        } catch (InterruptedException e) {
	            Thread.currentThread().interrupt();
	            return;
	        }
	    }
	    }
	 

